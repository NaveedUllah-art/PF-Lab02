#include <stdio.h>

int main()
{
    int n,n2, i, j;
    char symbol, symbol2;

    printf("Enter number of rows: ");
    scanf("%d", &n);

    printf("Enter a symbol: ");
    scanf(" %c", &symbol);
    
     printf("Enter number for rows2 or part 2: ");
    scanf("%d", &n2);

    printf("Enter a symbol2: ");
    scanf(" %c", &symbol2);
    

    // Upper part
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n - i; j++)
        {
            printf(" ");
        }

        for (j = 1; j <= 2 * i - 1; j++)
        {
            printf("%c", symbol);
        }

        printf("\n");
    }

    // Lower part
    for (i = n - 1; i >= 1; i--)
    {
        for (j = 1; j <= n - i; j++)
        {
            printf(" ");
        }

        for (j = 1; j <= 2 * i - 1; j++)
        {
            printf("%c", symbol);
        }

        printf("\n");
    }
    
    printf("\nthe second one is :\n\n");
    
     for (i = 1; i <=n2; i++)
    {
        for (j = 1; j <= n2 - i; j++)
        {
            printf(" ");
        }

        for (j = 1; j <= 2 * i - 1; j++)
        {
            printf("%c", symbol2);
        }

        printf("\n");
    }

    // Lower part
    for (i = n2 - 1; i >= 1; i--)
    {
        for (j = 1; j <= n2 - i; j++)
        {
            printf(" ");
        }

        for (j = 1; j <= 2 * i - 1; j++)
        {
            printf("%c", symbol2);
        }

        printf("\n");
    }


    return 0;
}