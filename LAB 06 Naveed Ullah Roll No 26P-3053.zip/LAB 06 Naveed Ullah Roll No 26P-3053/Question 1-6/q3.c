#include <stdio.h>


int main()
{
 int n,x,i,j,k,fact,power;  // i = k;  
 float series=0;

 
 printf("enter the value of n and x : \n");
 scanf("%d%d", &n, &x);
 for(i=0;i<=n;i++)
 {
  fact=1;
 power=1;
 
 for(j=1;j<=i;j++)
	 {
 	fact=fact*j;
	 }	
	 
 for(k=1;k<=i;k++)
	 {
	 power=power*x;
	 }

	series+=(float)power/fact;	 
}
printf(" Series = %.2f\n",series);
	 
	return 0;
}