#include <stdio.h>


int main()
{

	int i,j,k,n=5;
	for(i=1;i<=5;i++)
	{
		for(j=i;j<5;j++)
		printf(" ");
	for(k=1;k<=i;k++)
	{
		printf("*");
	}
	printf("\n");
	}
	
	
	printf("\n\n");
	
	for(i=1;i<=5;i++)
	{
		for(j=1;j<i;j++)
		{
			printf(" ");
		}
		for(k=i;k<=5;k++) 
		{
			printf("*");
		}
		printf("\n");
	}
	
	return 0;
}