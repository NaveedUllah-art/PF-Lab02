#include <stdio.h>


int main()
{

	int i,j,k;
	
	int n1,n2;
	
	printf("enter the value of num1  and num2 :\n");
	scanf("%d%d", &n1 , &n2);
	printf("\n output of first number:\n");
	for(i=1;i<=n1;i++)
	{
		for(j=1;j<=i;j++)
		{
		
		printf("#");
		}
		printf("\n");
	}
	
	for(i=n1-1;i>=1;i--)
	{
		for(j=1;j<=i;j++)
		{
			printf("#");
		}
		printf("\n");
	}
	
	printf("\n\nout of second number: \n\n");
	
		for(i=1;i<=n1;i++)
	{
		for(j=1;j<=i;j++)
		{
		
		printf("*");
		}
		printf("\n");
	}
	
	for(i=n2-1;i>=1;i--)
	{
		for(j=1;j<=i;j++)
		{
			printf("*");
		}
		printf("\n");
	}
	
	return 0;
}